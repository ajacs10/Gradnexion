// src/components/StudentProfilePage.jsx
import React, { useMemo, useState } from 'react';
import { Link, Navigate, useParams } from 'react-router-dom';
import { apiPatch, apiPost } from '../services/api';
import './HomePage.css';

const getConferenceUrl = (student) => {
  const roomName = `shecodeajacs-${student.id}-${student.name}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

  return `https://meet.jit.si/${roomName}`;
};

function StudentProfilePage({ graduates, onStudentMovedToInternship, session }) {
  const { id } = useParams();
  const [interviewMode, setInterviewMode] = useState('Presencial');
  const [meetingStatus, setMeetingStatus] = useState('');
  const [interview, setInterview] = useState(null);
  const student = graduates.find((graduate) => String(graduate.id) === id);

  const fallbackConferenceUrl = useMemo(() => (student ? getConferenceUrl(student) : ''), [student]);
  const conferenceUrl = interview?.meeting_url || fallbackConferenceUrl;

  if (!student) {
    return <Navigate to="/talentos" replace />;
  }

  const handleSchedule = async (mode) => {
    setInterviewMode(mode);
    try {
      const createdInterview = await apiPost('/api/interviews', {
        studentId: student.id,
        companyId: session.profile.id,
        mode,
      });
      setInterview(createdInterview);
      setMeetingStatus(
        mode === 'Presencial'
          ? 'Entrevista presencial marcada para validação da empresa.'
          : 'Entrevista via plataforma marcada. A empresa pode abrir a sala abaixo.',
      );
    } catch (error) {
      setMeetingStatus(error.message);
    }
  };

  const handleStartInternship = async () => {
    if (!interview) return;
    try {
      await apiPatch(`/api/interviews/${interview.id}/status`, { status: 'internship_started' });
      onStudentMovedToInternship?.(student.id);
      setMeetingStatus('Estudante marcado como aprovado para estágio nesta empresa.');
    } catch (error) {
      setMeetingStatus(error.message);
    }
  };

  return (
    <main className="homepage-main page-shell">
      <section className="student-profile-hero">
        <img className="student-profile-photo" src={student.photoUrl} alt={student.name} />
        <div>
          <p className="eyebrow">Perfil de estudante</p>
          <h2>{student.name}</h2>
          <p className="student-profile-role">
            {student.role} · {student.course}
          </p>
          <p>{student.quote}</p>
          <div className="graduate-meta">
            <span>{student.university}</span>
            <span>Turma {student.year}</span>
            {student.skills.map((skill) => (
              <span key={skill}>{skill}</span>
            ))}
          </div>
          <div className="profile-link-row">
            {student.portfolioUrl && (
              <a href={student.portfolioUrl} target="_blank" rel="noreferrer" className="secondary-action">
                Portfólio
              </a>
            )}
            {student.linkedinUrl && (
              <a href={student.linkedinUrl} target="_blank" rel="noreferrer" className="secondary-action">
                LinkedIn
              </a>
            )}
            {student.universityDeclarationUrl && (
              <a
                href={student.universityDeclarationUrl}
                target="_blank"
                rel="noreferrer"
                className="secondary-action"
              >
                Declaração
              </a>
            )}
          </div>
        </div>
      </section>

      <section className="profile-layout interview-layout">
        <article className="profile-summary">
          <h3>Marcar entrevista</h3>
          <p>
            A empresa pode preparar uma entrevista presencial ou via plataforma para avaliar este
            perfil antes de avançar com a contratação.
          </p>
          <div className="interview-actions" aria-label="Tipo de entrevista">
            <button type="button" onClick={() => handleSchedule('Presencial')}>
              Entrevista presencial
            </button>
            <button type="button" onClick={() => handleSchedule('Via plataforma')}>
              Via plataforma
            </button>
          </div>
          {meetingStatus && <p className="interview-status">{meetingStatus}</p>}
        </article>

        <aside className="profile-actions conference-panel">
          <h3>Conferência</h3>
          <p>Modo selecionado: {interviewMode}</p>
          <a href={conferenceUrl} target="_blank" rel="noreferrer" className="primary-action">
            Abrir sala de conferência
          </a>
          <button
            type="button"
            className="secondary-action action-button"
            onClick={handleStartInternship}
            disabled={!interview}
          >
            Marcar como aprovado para estágio
          </button>
          <Link to="/talentos" className="secondary-action">Voltar aos talentos</Link>
        </aside>
      </section>
    </main>
  );
}

export default StudentProfilePage;
