// src/components/TalentsPage.jsx
import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import journalContent from '../data/journalContent';
import { t } from '../i18n';
import './HomePage.css';

function TalentsPage({ graduates }) {
  const [selectedCourse, setSelectedCourse] = useState(t.common.all);
  const [searchTerm, setSearchTerm] = useState('');
  const courses = journalContent.courseAreas.map((course) => course.name);

  const filteredGraduates = useMemo(() => {
    const normalizedSearch = searchTerm.trim().toLowerCase();

    return graduates.filter((graduate) => {
      const matchesCourse = selectedCourse === t.common.all || graduate.course === selectedCourse;
      const searchable = [
        graduate.name,
        graduate.course,
        graduate.role,
        graduate.company,
        graduate.quote,
        ...(graduate.skills ?? []),
      ]
        .join(' ')
        .toLowerCase();

      return matchesCourse && (!normalizedSearch || searchable.includes(normalizedSearch));
    });
  }, [graduates, searchTerm, selectedCourse]);

  const getInitials = (name = '') =>
    name
      .split(' ')
      .map((part) => part[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();

  return (
    <main className="homepage-main page-shell">
      <section className="section-band">
        <div className="section-heading">
          <p className="eyebrow">{t.home.wallEyebrow}</p>
          <h2>{t.home.wallTitle}</h2>
          <p>{t.home.wallDescription}</p>
        </div>

        <div className="mural-toolbar">
          <label>
            <span>{t.home.search}</span>
            <input
              type="search"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder={t.home.searchPlaceholder}
            />
          </label>

          <label>
            <span>{t.home.course}</span>
            <select value={selectedCourse} onChange={(event) => setSelectedCourse(event.target.value)}>
              <option>{t.common.all}</option>
              {courses.map((course) => (
                <option key={course}>{course}</option>
              ))}
            </select>
          </label>
        </div>

        <div className="graduate-grid">
          {filteredGraduates.map((graduate) => (
            <article className="graduate-card graduate-card-clickable" key={graduate.id}>
              <Link to={`/talentos/${graduate.id}`} className="graduate-profile-link">
                {graduate.photoUrl ? (
                  <img className="graduate-photo" src={graduate.photoUrl} alt={graduate.name} />
                ) : (
                  <span className="graduate-photo graduate-photo-fallback">{getInitials(graduate.name)}</span>
                )}
              </Link>
              <div className="graduate-card-body">
                <div>
                  <p className="graduate-course">{graduate.course}</p>
                  <h3>
                    <Link to={`/talentos/${graduate.id}`}>{graduate.name}</Link>
                  </h3>
                  <p className="graduate-role">
                    {graduate.role} · {graduate.company}
                  </p>
                  <p className="graduate-university">{graduate.university}</p>
                </div>
                <blockquote>{graduate.quote}</blockquote>
                <div className="graduate-meta">
                  <span>{t.home.classPrefix} {graduate.year}</span>
                  {(graduate.skills ?? []).map((skill) => (
                    <span key={skill}>{skill}</span>
                  ))}
                  {graduate.portfolioUrl && (
                    <a href={graduate.portfolioUrl} target="_blank" rel="noreferrer">
                      Portfólio
                    </a>
                  )}
                  {graduate.linkedinUrl && (
                    <a href={graduate.linkedinUrl} target="_blank" rel="noreferrer">
                      LinkedIn
                    </a>
                  )}
                </div>
              </div>
            </article>
          ))}
          {filteredGraduates.length === 0 && (
            <p className="empty-state">Nenhum talento disponível para estes filtros.</p>
          )}
        </div>
      </section>
    </main>
  );
}

export default TalentsPage;
